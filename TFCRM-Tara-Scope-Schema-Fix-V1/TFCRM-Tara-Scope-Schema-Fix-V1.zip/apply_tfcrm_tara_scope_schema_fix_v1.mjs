#!/usr/bin/env node
import { config as dotenvConfig } from "dotenv";
import mysql from "mysql2/promise";
import path from "node:path";

dotenvConfig({ path: path.join(process.cwd(), ".env"), override: true });

const TABLE = "tara_moderator_account_scopes";
const APPLY = process.argv.includes("--apply");
const LOCK_NAME = "tfcrm_tara_scope_schema_fix_v1";

const LEGACY_COLUMNS = [
  { name: "id", dataType: "int", nullable: "NO" },
  { name: "moderator_id", dataType: "int", nullable: "NO" },
  { name: "scope_type", dataType: "varchar", nullable: "NO", maxLength: 64 },
  { name: "scope_id", dataType: "int", nullable: "NO" },
  { name: "created_at", dataType: "timestamp", nullable: "NO" },
];

const CURRENT_COLUMNS = [
  { name: "id", dataType: "int", nullable: "NO" },
  { name: "user_id", dataType: "int", nullable: "NO" },
  { name: "platform", dataType: "varchar", nullable: "NO", maxLength: 64 },
  { name: "account_id", dataType: "varchar", nullable: "NO", maxLength: 255 },
  { name: "created_by", dataType: "int", nullable: "YES" },
  { name: "created_at", dataType: "timestamp", nullable: "NO" },
];

const EXPECTED_CURRENT_INDEXES = {
  PRIMARY: { unique: true, columns: ["id"] },
  uq_tara_moderator_scope: {
    unique: true,
    columns: ["user_id", "platform", "account_id"],
  },
  idx_tara_moderator_scope_user: {
    unique: false,
    columns: ["user_id"],
  },
};

function fail(message) {
  throw new Error(message);
}

function parseDatabaseUrl() {
  const raw = String(process.env.DATABASE_URL || "").trim();
  if (raw) {
    const url = new URL(raw);
    if (!["mysql:", "mariadb:"].includes(url.protocol)) {
      fail("DATABASE_URL must be MySQL/MariaDB");
    }
    return {
      host: url.hostname,
      port: Number(url.port || 3306),
      user: decodeURIComponent(url.username),
      password: decodeURIComponent(url.password),
      database: url.pathname.replace(/^\//, ""),
      multipleStatements: false,
    };
  }

  const cfg = {
    host: process.env.DB_HOST || process.env.MYSQL_HOST || "127.0.0.1",
    port: Number(process.env.DB_PORT || process.env.MYSQL_PORT || 3306),
    user: process.env.DB_USER || process.env.MYSQL_USER || "",
    password: process.env.DB_PASSWORD || process.env.MYSQL_PASSWORD || "",
    database: process.env.DB_NAME || process.env.MYSQL_DATABASE || "",
    multipleStatements: false,
  };
  if (!cfg.user || !cfg.database) {
    fail("DATABASE_URL or DB_HOST/DB_USER/DB_PASSWORD/DB_NAME is required");
  }
  return cfg;
}

function safeError(error) {
  return String(error?.message || error)
    .replace(
      /(password|passwd|pwd|token|secret)\s*[:=]\s*[^\s,;]+/gi,
      "$1=[REDACTED]",
    )
    .replace(/[\r\n\t]+/g, " ")
    .slice(0, 900);
}

async function getTableMeta(conn) {
  const [rows] = await conn.query(
    `SELECT TABLE_NAME, ENGINE, TABLE_COLLATION
       FROM information_schema.TABLES
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = ?`,
    [TABLE],
  );
  return rows[0] || null;
}

async function getColumns(conn) {
  const [rows] = await conn.query(
    `SELECT
       COLUMN_NAME AS name,
       DATA_TYPE AS dataType,
       COLUMN_TYPE AS columnType,
       IS_NULLABLE AS nullable,
       CHARACTER_MAXIMUM_LENGTH AS maxLength,
       COLUMN_DEFAULT AS defaultValue,
       COLUMN_KEY AS columnKey,
       EXTRA AS extra,
       ORDINAL_POSITION AS ordinalPosition
     FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = ?
     ORDER BY ORDINAL_POSITION`,
    [TABLE],
  );
  return rows;
}

async function getIndexes(conn) {
  const [rows] = await conn.query(
    `SELECT
       INDEX_NAME AS indexName,
       NON_UNIQUE AS nonUnique,
       SEQ_IN_INDEX AS seqInIndex,
       COLUMN_NAME AS columnName
     FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE()
       AND TABLE_NAME = ?
     ORDER BY INDEX_NAME, SEQ_IN_INDEX`,
    [TABLE],
  );

  const map = new Map();
  for (const row of rows) {
    const name = String(row.indexName);
    const item = map.get(name) || {
      unique: Number(row.nonUnique) === 0,
      columns: [],
    };
    item.columns.push(String(row.columnName));
    map.set(name, item);
  }
  return map;
}

function columnMap(rows) {
  return new Map(rows.map((row) => [String(row.name), row]));
}

function definitionMatches(row, expected) {
  if (!row) return false;
  if (String(row.dataType).toLowerCase() !== expected.dataType) return false;
  if (String(row.nullable).toUpperCase() !== expected.nullable) return false;
  if (
    expected.maxLength != null &&
    Number(row.maxLength || 0) !== expected.maxLength
  ) return false;
  return true;
}

function exactColumnSet(rows, expected) {
  if (rows.length !== expected.length) return false;
  const map = columnMap(rows);
  return expected.every((item) => definitionMatches(map.get(item.name), item));
}

function indexMatches(actual, expected) {
  if (!actual) return false;
  return (
    actual.unique === expected.unique &&
    JSON.stringify(actual.columns) === JSON.stringify(expected.columns)
  );
}

function currentIndexesCorrect(indexes) {
  const names = [...indexes.keys()].sort();
  const expectedNames = Object.keys(EXPECTED_CURRENT_INDEXES).sort();
  if (JSON.stringify(names) !== JSON.stringify(expectedNames)) return false;
  return Object.entries(EXPECTED_CURRENT_INDEXES).every(([name, expected]) =>
    indexMatches(indexes.get(name), expected),
  );
}

function legacyIndexesSafe(indexes) {
  const names = [...indexes.keys()];
  if (names.length !== 1 || names[0] !== "PRIMARY") return false;
  return indexMatches(indexes.get("PRIMARY"), {
    unique: true,
    columns: ["id"],
  });
}

async function exactRowCount(conn) {
  const [rows] = await conn.query(
    `SELECT COUNT(*) AS rowCount FROM \`${TABLE}\``,
  );
  return Number(rows?.[0]?.rowCount || 0);
}

async function verifyCurrentSchema(conn) {
  const columns = await getColumns(conn);
  const indexes = await getIndexes(conn);

  if (!exactColumnSet(columns, CURRENT_COLUMNS)) {
    fail("Verification failed: current columns do not exactly match expected schema");
  }

  const id = columnMap(columns).get("id");
  if (
    !String(id?.extra || "").toLowerCase().includes("auto_increment")
  ) {
    fail("Verification failed: id is not AUTO_INCREMENT");
  }

  const createdAt = columnMap(columns).get("created_at");
  const createdDefault =
    createdAt?.defaultValue == null ? null : String(createdAt.defaultValue);
  if (
    createdDefault !== "CURRENT_TIMESTAMP" &&
    createdDefault !== "current_timestamp()"
  ) {
    fail(
      `Verification failed: created_at default is ${createdDefault ?? "NULL"}`,
    );
  }

  if (!currentIndexesCorrect(indexes)) {
    fail("Verification failed: current indexes do not match expected schema");
  }

  await conn.query(
    `SELECT \`id\`, \`user_id\`
       FROM \`${TABLE}\`
      WHERE \`platform\` = ?
        AND \`account_id\` = ?
      LIMIT 50`,
    ["evolution_whatsapp", "3"],
  );

  return { columns, indexes };
}

async function main() {
  const conn = await mysql.createConnection(parseDatabaseUrl());
  let lockAcquired = false;

  try {
    const meta = await getTableMeta(conn);
    if (!meta) fail(`${TABLE} does not exist`);
    if (String(meta.ENGINE || "").toUpperCase() !== "INNODB") {
      fail(`Safety stop: ${TABLE} engine is not InnoDB`);
    }

    const columns = await getColumns(conn);
    const indexes = await getIndexes(conn);
    const rows = await exactRowCount(conn);

    const alreadyCurrent =
      exactColumnSet(columns, CURRENT_COLUMNS) &&
      currentIndexesCorrect(indexes);

    const exactLegacy =
      exactColumnSet(columns, LEGACY_COLUMNS) &&
      legacyIndexesSafe(indexes);

    console.log("TFCRM_TARA_SCOPE_SCHEMA_FIX_V1");
    console.log(`MODE=${APPLY ? "APPLY" : "DRY_RUN"}`);
    console.log("TABLE_EXISTS=YES");
    console.log(`TABLE_ENGINE=${meta.ENGINE}`);
    console.log(`ROW_COUNT=${rows}`);
    console.log(`SCHEMA_STATE=${alreadyCurrent ? "CURRENT" : exactLegacy ? "LEGACY_EXACT" : "UNKNOWN"}`);

    if (alreadyCurrent) {
      await verifyCurrentSchema(conn);
      console.log("ACTION=NO_CHANGE_ALREADY_CURRENT");
      console.log("QUERY_SMOKE=PASS");
      console.log("DB_SCHEMA_CHANGED=NO");
      console.log("DB_DATA_CHANGED=NO");
      console.log("RESULT=PASS");
      return;
    }

    if (!exactLegacy) {
      fail("Safety stop: live table is neither exact legacy schema nor exact current schema");
    }

    if (rows !== 0) {
      fail(
        `Safety stop: legacy table contains ${rows} row(s); automatic conversion is intentionally blocked`,
      );
    }

    const plannedSql =
      "ALTER TABLE `tara_moderator_account_scopes` " +
      "CHANGE COLUMN `moderator_id` `user_id` INT NOT NULL, " +
      "CHANGE COLUMN `scope_type` `platform` VARCHAR(64) NOT NULL, " +
      "CHANGE COLUMN `scope_id` `account_id` VARCHAR(255) NOT NULL, " +
      "ADD COLUMN `created_by` INT NULL AFTER `account_id`, " +
      "MODIFY COLUMN `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
      "ADD UNIQUE KEY `uq_tara_moderator_scope` (`user_id`,`platform`,`account_id`), " +
      "ADD KEY `idx_tara_moderator_scope_user` (`user_id`)";

    console.log(`PLANNED_SQL=${plannedSql}`);

    if (!APPLY) {
      console.log("ACTION=DRY_RUN_ONLY");
      console.log("DB_SCHEMA_CHANGED=NO");
      console.log("DB_DATA_CHANGED=NO");
      console.log("RESULT=DRY_RUN_PASS");
      return;
    }

    const [lockRows] = await conn.query(
      "SELECT GET_LOCK(?, 10) AS acquired",
      [LOCK_NAME],
    );
    lockAcquired = Number(lockRows?.[0]?.acquired || 0) === 1;
    if (!lockAcquired) fail("Could not acquire migration lock");

    // Re-check immediately under the advisory lock.
    const columnsAgain = await getColumns(conn);
    const indexesAgain = await getIndexes(conn);
    const rowsAgain = await exactRowCount(conn);

    if (
      !exactColumnSet(columnsAgain, LEGACY_COLUMNS) ||
      !legacyIndexesSafe(indexesAgain)
    ) {
      fail("Safety stop: schema changed between dry-run and apply");
    }
    if (rowsAgain !== 0) {
      fail(`Safety stop: row count changed to ${rowsAgain} before apply`);
    }

    await conn.query(
      `ALTER TABLE \`${TABLE}\`
        CHANGE COLUMN \`moderator_id\` \`user_id\` INT NOT NULL,
        CHANGE COLUMN \`scope_type\` \`platform\` VARCHAR(64) NOT NULL,
        CHANGE COLUMN \`scope_id\` \`account_id\` VARCHAR(255) NOT NULL,
        ADD COLUMN \`created_by\` INT NULL AFTER \`account_id\`,
        MODIFY COLUMN \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        ADD UNIQUE KEY \`uq_tara_moderator_scope\` (\`user_id\`, \`platform\`, \`account_id\`),
        ADD KEY \`idx_tara_moderator_scope_user\` (\`user_id\`)`,
    );

    await verifyCurrentSchema(conn);

    const rowsAfter = await exactRowCount(conn);
    if (rowsAfter !== 0) {
      fail(`Verification failed: row count unexpectedly became ${rowsAfter}`);
    }

    console.log("ACTION=LEGACY_SCHEMA_CONVERTED");
    console.log("CURRENT_COLUMNS=id,user_id,platform,account_id,created_by,created_at");
    console.log("CURRENT_INDEXES=PRIMARY,uq_tara_moderator_scope,idx_tara_moderator_scope_user");
    console.log("QUERY_SMOKE=PASS");
    console.log("ROW_COUNT_AFTER=0");
    console.log("DB_SCHEMA_CHANGED=YES");
    console.log("DB_DATA_CHANGED=NO");
    console.log("SOURCE_CODE_CHANGED=NO");
    console.log("EVOLUTION_TOUCHED=NO");
    console.log("RESULT=PASS");
  } finally {
    if (lockAcquired) {
      await conn
        .query("SELECT RELEASE_LOCK(?)", [LOCK_NAME])
        .catch(() => undefined);
    }
    await conn.end().catch(() => undefined);
  }
}

main().catch((error) => {
  console.error("RESULT=FAIL");
  console.error(`ERROR=${safeError(error)}`);
  process.exitCode = 1;
});
